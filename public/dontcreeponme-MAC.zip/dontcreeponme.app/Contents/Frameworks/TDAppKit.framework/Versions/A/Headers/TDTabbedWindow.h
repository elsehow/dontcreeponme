//
//  TDTabbedWindow.h
//  TDAppKit
//
//  Created by Todd Ditchendorf on 11/12/10.
//  Copyright 2010 Todd Ditchendorf. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface TDTabbedWindow : NSWindow {

}

@end
