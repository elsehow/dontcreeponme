//
//  TDStatusBarButtonCell.h
//  TDAppKit
//
//  Created by Todd Ditchendorf on 11/23/12.
//  Copyright (c) 2012 Todd Ditchendorf. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface TDStatusBarButtonCell : NSButtonCell

@end
